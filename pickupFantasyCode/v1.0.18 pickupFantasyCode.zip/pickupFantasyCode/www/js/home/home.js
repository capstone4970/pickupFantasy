var body = document.getElementById("contentWrapper");

// fill in the logged in form
var create = document.createElement("button");
var join = document.createElement("button");
var view = document.createElement("button");

create.innerHTML = "Create League";
create.className = "myButton";

join.innerHTML = "Join League";
join.className = "myButton";

view.innerHTML = "View League";
view.className = "myButton";

create.onclick = function() {
    loadScript("js/league/createLeague.js");
};
join.onclick = function() {
    loadScript("js/league/joinLeague.js");
};
view.onclick = function() {
	
};

// add stylings for page                
body.style.textAlign = "center";
body.style.paddingTop = "80%";
body.style.marginLeft = "1%";

// add elements to page
body.appendChild(create);
body.appendChild(join);
body.appendChild(view);