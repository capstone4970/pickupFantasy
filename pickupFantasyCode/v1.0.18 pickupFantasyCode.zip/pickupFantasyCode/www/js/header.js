/* variables need for construction of header */
var header = document.getElementById("headerWrapper");
var loggedIn = localStorage.getItem("loggedIn");

/* constructing elements of the header */
var logo = document.createElement("img");
logo.src="img/introPlayer.png";
logo.className = "footballPlayer";


var logout = document.createElement("span");
logout.className = "logout";
if( (loggedIn == null) ) {
	logout.innerHTML = "Sign up";
	logout.onclick = function() {
		fillButton("signup", logout);
	}
}
else {	
	var home = document.createElement("span");
	home.className = "left";
	home.innerHTML = "Home";
	home.onclick = function() {
		loadScript("js/home/home.js");
	}
	header.appendChild(home);

	logout.innerHTML = "Log out";
	logout.onclick = function() {
		fillButton("logout", logout)
	}
}

header.appendChild(logout);
header.appendChild(logo);

function fillButton(page, element) {
	if(page == "login") {
		element.innerHTML = "Sign up";
		element.onclick = function() {
			fillButton("signup", element);
		}
		loadScript("js/home/login.js");
	}
	else if(page == "signup") {
		element.innerHTML = "Log in";
		element.onclick = function() {
			fillButton("login",element);
		}
		loadScript("js/home/signup.js");
	}
	else {
		localStorage.removeItem("loggedIn");
     	location.reload();
	}
}